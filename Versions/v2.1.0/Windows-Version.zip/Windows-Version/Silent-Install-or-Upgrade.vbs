' =====================================================================================
' Gestione Corsi v2.1.0 — Windows 11 Silent GUI Installer & Upgrader
' Concepito e Sviluppato da Guaira Jaramillo Nitoglia (guaira.jaramillo.nitoglia@gmail.com)
' =====================================================================================
Option Explicit
Dim fso, shell, scriptDir, cmdPath
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
cmdPath = chr(34) & scriptDir & "\Install-or-Upgrade-Gestione-Corsi.cmd" & chr(34)
shell.Run cmdPath, 1, False
