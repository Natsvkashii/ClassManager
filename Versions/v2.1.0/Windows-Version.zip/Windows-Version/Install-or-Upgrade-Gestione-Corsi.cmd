@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
title Gestione Corsi v2.1.0 — Windows 11 Native Installer ^& Upgrader

echo ===============================================================================
echo   GESTIONE CORSI v2.1.0 — WINDOWS 11 NATIVE INSTALLER ^& UPGRADER
echo   Concepito e Sviluppato da Guaira Jaramillo Nitoglia
echo   Contatto: guaira.jaramillo.nitoglia@gmail.com
echo ===============================================================================
echo.

set "APP_VERSION=2.1.0"
set "SCRIPT_DIR=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\GestioneCorsi"
set "DATA_DIR=%LOCALAPPDATA%\GestioneCorsi"

:: 1. Detect Existing Installation (Upgrade vs Fresh Install)
if exist "%INSTALL_DIR%\GestioneCorsi.exe" (
    set "PREV_VER=precedente"
    if exist "%INSTALL_DIR%\version.txt" (
        set /p PREV_VER=<"%INSTALL_DIR%\version.txt"
    )
    echo [AGGIORNAMENTO] Rilevata installazione esistente (v!PREV_VER!).
    echo Aggiornamento in corso alla versione v%APP_VERSION% preservando tutti i dati...
    taskkill /IM "GestioneCorsi.exe" /F >nul 2>&1
    timeout /t 1 /nobreak >nul 2>&1
) else (
    echo [INSTALLAZIONE] Nuova installazione di Gestione Corsi v%APP_VERSION% in corso...
)

:: 2. Create Directories (Local & OneDrive)
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\src" mkdir "%INSTALL_DIR%\src"
if not exist "%INSTALL_DIR%\assets" mkdir "%INSTALL_DIR%\assets"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"

if defined OneDrive (
    if exist "%OneDrive%" (
        if not exist "%OneDrive%\GestioneCorsi" mkdir "%OneDrive%\GestioneCorsi"
        echo [ONEDRIVE] Cartella cloud Microsoft OneDrive configurata: "%OneDrive%\GestioneCorsi"
    )
)

:: 3. Copy Application Assets & Source Files
copy /Y "%SCRIPT_DIR%assets\AppIcon.ico" "%INSTALL_DIR%\AppIcon.ico" >nul
copy /Y "%SCRIPT_DIR%assets\logo.png" "%INSTALL_DIR%\logo.png" >nul
copy /Y "%SCRIPT_DIR%assets\app.manifest" "%INSTALL_DIR%\app.manifest" >nul
copy /Y "%SCRIPT_DIR%assets\*.*" "%INSTALL_DIR%\assets\" >nul
copy /Y "%SCRIPT_DIR%src\*.cs" "%INSTALL_DIR%\src\" >nul
echo %APP_VERSION%> "%INSTALL_DIR%\version.txt"

:: 4. Locate Built-in Windows .NET Framework 4.x C# Compiler (csc.exe)
set "CSC_PATH=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC_PATH%" (
    set "CSC_PATH=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)
if not exist "%CSC_PATH%" (
    echo [ERRORE] Compilatore di sistema .NET Framework non trovato in %WINDIR%\Microsoft.NET.
    pause
    exit /b 1
)

echo.
echo [COMPILAZIONE NATIVA] Generazione dell'eseguibile nativo Windows 11 (GestioneCorsi.exe)...
"%CSC_PATH%" /nologo /target:winexe /optimize+ ^
    /out:"%INSTALL_DIR%\GestioneCorsi.exe" ^
    /win32icon:"%INSTALL_DIR%\AppIcon.ico" ^
    /win32manifest:"%INSTALL_DIR%\app.manifest" ^
    /r:System.dll ^
    /r:System.Core.dll ^
    /r:System.Drawing.dll ^
    /r:System.Windows.Forms.dll ^
    /r:System.Web.Extensions.dll ^
    /r:System.Xml.dll ^
    "%INSTALL_DIR%\src\Models.cs" ^
    "%INSTALL_DIR%\src\Localization.cs" ^
    "%INSTALL_DIR%\src\FluentTheme.cs" ^
    "%INSTALL_DIR%\src\AppStore.cs" ^
    "%INSTALL_DIR%\src\Modals.cs" ^
    "%INSTALL_DIR%\src\MainForm.cs"

if errorlevel 1 (
    echo.
    echo [ERRORE] Compilazione fallita. Verifica i messaggi sopra riportati.
    pause
    exit /b 1
)

:: Also place a portable copy of GestioneCorsi.exe in the installer folder
copy /Y "%INSTALL_DIR%\GestioneCorsi.exe" "%SCRIPT_DIR%GestioneCorsi.exe" >nul 2>&1
copy /Y "%INSTALL_DIR%\AppIcon.ico" "%SCRIPT_DIR%AppIcon.ico" >nul 2>&1
copy /Y "%INSTALL_DIR%\logo.png" "%SCRIPT_DIR%logo.png" >nul 2>&1

:: 5. Generate Uninstaller Script
(
echo @echo off
echo title Disinstallazione Gestione Corsi
echo taskkill /IM "GestioneCorsi.exe" /F ^>nul 2^>^&1
echo del /F /Q "%USERPROFILE%\Desktop\Gestione Corsi.lnk" ^>nul 2^>^&1
echo del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Gestione Corsi.lnk" ^>nul 2^>^&1
echo reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /f ^>nul 2^>^&1
echo echo Disinstallazione completata. I dati utente in OneDrive e AppData sono stati preservati.
echo rmdir /S /Q "%INSTALL_DIR%"
) > "%INSTALL_DIR%\Uninstall-GestioneCorsi.cmd"

:: 6. Register in Windows 11 Installed Apps (Settings -> Apps -> Installed Apps)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "DisplayName" /t REG_SZ /d "Gestione Corsi" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "DisplayVersion" /t REG_SZ /d "%APP_VERSION%" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "Publisher" /t REG_SZ /d "Guaira Jaramillo Nitoglia (guaira.jaramillo.nitoglia@gmail.com)" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "DisplayIcon" /t REG_SZ /d "%INSTALL_DIR%\AppIcon.ico" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "InstallLocation" /t REG_SZ /d "%INSTALL_DIR%" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "UninstallString" /t REG_SZ /d "\"%INSTALL_DIR%\Uninstall-GestioneCorsi.cmd\"" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "NoModify" /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestioneCorsi" /v "NoRepair" /t REG_DWORD /d 0 /f >nul

:: 7. Create Desktop & Start Menu Shortcuts (.lnk) via PowerShell WScript.Shell
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$ws = New-Object -ComObject WScript.Shell; ^
     $desk = [Environment]::GetFolderPath('Desktop'); ^
     $s1 = $ws.CreateShortcut((Join-Path $desk 'Gestione Corsi.lnk')); ^
     $s1.TargetPath = '%INSTALL_DIR%\GestioneCorsi.exe'; ^
     $s1.WorkingDirectory = '%INSTALL_DIR%'; ^
     $s1.IconLocation = '%INSTALL_DIR%\AppIcon.ico,0'; ^
     $s1.Description = 'Gestione Corsi v2.1.0 — Guaira Jaramillo Nitoglia'; ^
     $s1.Save(); ^
     $startMenu = [Environment]::GetFolderPath('Programs'); ^
     $s2 = $ws.CreateShortcut((Join-Path $startMenu 'Gestione Corsi.lnk')); ^
     $s2.TargetPath = '%INSTALL_DIR%\GestioneCorsi.exe'; ^
     $s2.WorkingDirectory = '%INSTALL_DIR%'; ^
     $s2.IconLocation = '%INSTALL_DIR%\AppIcon.ico,0'; ^
     $s2.Description = 'Gestione Corsi v2.1.0 — Guaira Jaramillo Nitoglia'; ^
     $s2.Save();" >nul 2>&1

echo.
echo ===============================================================================
echo   INSTALLAZIONE / AGGIORNAMENTO COMPLETATO CON SUCCESSO!
echo   - Percorso App: %INSTALL_DIR%\GestioneCorsi.exe
echo   - Collegamenti creati sul Desktop e nel Menu Start di Windows 11
echo   - Sincronizzazione OneDrive pronta (%OneDrive%\GestioneCorsi)
echo ===============================================================================
echo.
start "" "%INSTALL_DIR%\GestioneCorsi.exe"
exit /b 0
