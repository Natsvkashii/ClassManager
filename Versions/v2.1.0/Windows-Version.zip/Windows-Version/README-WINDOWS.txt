=====================================================================================
GESTIONE CORSI v2.1.0 — WINDOWS 11 NATIVE EDITION (Fluent UI + Microsoft OneDrive)
Concepito e Sviluppato da Guaira Jaramillo Nitoglia (guaira.jaramillo.nitoglia@gmail.com)
=====================================================================================

COME INSTALLARE O AGGIORNARE SU WINDOWS 10 / WINDOWS 11:
1. Estrai l'archivio "Gestione-Corsi-2.1.0-Windows.zip" in una cartella sul tuo PC Windows.
2. Fai doppio clic su:
   - "Install-or-Upgrade-Gestione-Corsi.cmd"
3. L'installer:
   - Compila e installa l'app nativa Windows 11 in %LOCALAPPDATA%\Programs\GestioneCorsi\GestioneCorsi.exe
     usando le librerie predefinite di Windows (.NET Framework di sistema, senza installare runtime esterni).
   - Se una versione precedente è già presente, esegue automaticamente l'AGGIORNAMENTO (Upgrade)
     preservando tutti i tuoi corsi, studenti, presenze e valutazioni.
   - Crea i collegamenti "Gestione Corsi" sul Desktop e nel Menu Start di Windows 11 con l'icona personalizzata.
   - Registra il programma nelle App Installate di Windows 11 (Impostazioni -> App -> App installate).
   - Attiva la sincronizzazione automatica con Microsoft OneDrive (%OneDrive%\GestioneCorsi\gestione_corsi_state_v1.json).

HOW TO INSTALL OR UPGRADE ON WINDOWS 10 / WINDOWS 11:
1. Extract "Gestione-Corsi-2.1.0-Windows.zip" on your Windows PC.
2. Double-click "Install-or-Upgrade-Gestione-Corsi.cmd".
3. The installer automatically installs or upgrades the native Windows 11 app, creates Desktop and
   Start Menu shortcuts, registers the app in Windows Settings -> Apps, and syncs via Microsoft OneDrive.
